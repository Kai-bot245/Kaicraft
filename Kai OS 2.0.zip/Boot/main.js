const kaiinternet = () => {
open("../Kai Internet/internet.html")
}
const kaicraft = () => {
open("../Kaicraft/index.html")
}
const kaicommander = () => {
open("../Kai Commander/kaicommander.html")
}
const kaisettings = () => {
  open("../Kai Settings/index.html")
}
    var backgroundImage = localStorage.getItem('backgroundImage');
    if (backgroundImage) {
      document.body.style.backgroundImage = 'url(' + backgroundImage + ')';
    }