const img = document.getElementById("image");

// Functions to change the selected block type
const stone = () => { img.src = "block/stone.png"; };
const grass = () => { img.src = "block/grass.png"; };
const iron = () => { img.src = "block/iron.png"; };
const diamond = () => { img.src = "block/diamond.png"; };
const planks = () => { img.src = "block/planks.png"; };

// Function to handle placing a block
const placeBlock = (x, y) => {
    const newImage = document.createElement('img');
    newImage.src = img.src; // Use the current selected block type
    newImage.style.position = 'absolute';
    newImage.style.left = `${x}px`;
    newImage.style.top = `${y}px`;
    document.body.appendChild(newImage);
};

// Function to remove a block
const breakBlock = (element) => {
    element.remove();
};

// Event listener for placing and breaking blocks
document.addEventListener('click', (event) => {
    const elements = document.elementsFromPoint(event.clientX, event.clientY);
    const block = elements.find(el => el.tagName === 'IMG' && el !== img);
    if (block) {
        breakBlock(block);
    } else if (event.target === document.body || event.target.tagName !== 'IMG') {
        placeBlock(event.clientX, event.clientY);
    }
});

// Initialize the selected block type to grass
grass();
// Make a Player

const canvas = document.getElementById("canvas")
const ctx = canvas.getContext("2d")

let x = 0;
let y = 0;
let vx = 0;
let vy = 0;
// Define a player object with customizable properties
// Define a player object with customizable properties
const player = {
    x: 0, // Starting x position
    y: 0, // Starting y position
    width: 50, // Width of the player
    height: 100, // Height of the player
    color: 'yellow' // Color of the player
};

// Function to draw the player
function drawPlayer() {
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);
}

// Update the update function to include drawPlayer and update player position
function update() {
    canvas.height = window.innerHeight;
    canvas.width = window.innerWidth;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    player.x += vx; // Update player's x position
    player.y += vy; // Update player's y position
    drawPlayer(); // Draw the player on the canvas
    requestAnimationFrame(update); // Call update before the next repaint
}

// Start the game loop
requestAnimationFrame(update);

// Event listeners for arrow keys to move the player object
addEventListener('keydown', function(e){
    if (e.code == 'KeyD') vx = 5;
    if (e.code == 'KeyA') vx = -5;
    if (e.code == 'KeyW') vy = -5;
    if (e.code == 'KeyS') vy = 5;
});
addEventListener('keyup', function(e){
    if (e.code == 'KeyD' || e.code == 'KeyA') vx = 0;
    if (e.code == 'KeyW' || e.code == 'KeyS') vy = 0;
});
const red = () => {
player.color = 'red';
}
const orange = () => {
player.color = 'orange';
}
const yellow = () => {
player.color = 'yellow';
}
const green = () => {
player.color = 'green';
}
const blue = () => {
player.color = 'blue';
}
const purple = () => {
player.color = 'purple';
}
// Function to display player's position
function displayPlayerPosition() {
  const positionElement = document.getElementById('playerPosition');
  positionElement.textContent = 'Player Position - X: ' + player.x + ', Y: ' + player.y;
requestAnimationFrame(displayPlayerPosition)
}
displayPlayerPosition()
let name = "steve"
function teleportPlayer() {
  var command = document.getElementById('commandInput').value;
  var args = command.split(' '); // Split the command into parts
  // Check if the command is in the correct format
  if (args[0] === '/tp' && args.length === 4) {
    name = args[1];
    player.x = parseInt(args[2]);
    player.y = parseInt(args[3]);
    console.log('Teleporting ' + player.name + ' to X=' + player.x + ', Y=' + player.y);
    // Additional logic to handle teleportation can be added here
  }
}
function namemaker(){
  var nameinput = document.getElementById("name").value;
  nameinput = name;
}

// Variables to store the frame times
var filterStrength = 20;
var frameTime = 0, lastLoop = new Date(), thisLoop;

// The game loop function
function gameLoop() {
  // ... your game logic here ...

  // Calculate the time since the last loop
  var thisFrameTime = (thisLoop = new Date()) - lastLoop;
  frameTime += (thisFrameTime - frameTime) / filterStrength;
  lastLoop = thisLoop;
}

// Display the FPS in a <p> tag with the id 'fps'
var fpsOut = document.getElementById('fps');
setInterval(function(){
  fpsOut.innerHTML = (1000 / frameTime).toFixed(1) + " FPS";
}, 1000);
// Start the game loop
setInterval(gameLoop, 10);
// Get the audio element with the id "background-music"
var music = document.getElementById("background-music");
// Add an event listener for a user interaction, such as 'click'
addEventListener('click', function(){
  // Play the music
  music.play();
})
// Initial state of the toggle
let isDay = true;

// Function to switch the state and perform the toggle
function toggleDayNight() {
  // Switch the state
  isDay = !isDay;

  // Get the body element
  const body = document.body;

  // Set the background color based on the state
  body.style.backgroundColor = isDay ? "cyan" : "#031A9E";
}

// Call the function every 10 minutes
setInterval(toggleDayNight, 600000); // 10 minutes