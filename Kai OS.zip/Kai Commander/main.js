function displayText() {
  // Get the value from the textarea
  var text = document.getElementById('inputText').value;

  // Get the display element
  var displayElement = document.getElementById('displayText');

  // Set the text
  displayElement.textContent = text;

  // Toggle the flashing underscore
  if (text) {
    displayElement.classList.add('flashing');
  } else {
    displayElement.classList.remove('flashing');
  }
}
