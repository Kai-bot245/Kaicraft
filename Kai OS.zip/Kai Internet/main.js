function go() {
  var siteUrl = document.querySelector('.site').value;
  if (siteUrl) {
    window.open(siteUrl, '_blank');
  } else {
    alert('Please enter a valid site URL.');
  }
}